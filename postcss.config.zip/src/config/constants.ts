export const BLOG_CONFIG = {
  BLOG_URL: 'https://yyghcggh.blogspot.com',
  TITLE: 'My Blog',
  DESCRIPTION: 'Welcome to my blog',
};