import { Post, Category, Author } from '../types/blog';

export const categories: Category[] = [
  { id: '1', name: 'Technology', slug: 'technology' },
  { id: '2', name: 'Travel', slug: 'travel' },
  { id: '3', name: 'Lifestyle', slug: 'lifestyle' },
];

export const authors: Author[] = [
  {
    id: '1',
    name: 'John Doe',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop',
    bio: 'Tech enthusiast and professional blogger',
  },
];

export const posts: Post[] = [
  {
    id: '1',
    title: 'Getting Started with React Development',
    content: 'Lorem ipsum dolor sit amet...',
    excerpt: 'Learn the basics of React development and how to create your first application.',
    slug: 'getting-started-with-react',
    date: '2024-03-15',
    author: authors[0],
    categories: [categories[0]],
    featuredImage: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=1200&h=800&fit=crop',
  },
  // Add more sample posts as needed
];